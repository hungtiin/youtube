<?php 
$upload_services[]="novafile.com_member";
$max_file_size["novafile.com_member"]=2000;
$page_upload["novafile.com_member"] = "novafile.com_member.php";
?>