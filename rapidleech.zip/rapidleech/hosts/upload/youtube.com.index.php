<?php
$upload_services[]="youtube.com";
$max_file_size["youtube.com"]=1000;
$page_upload["youtube.com"] = "youtube.com.php";
?>