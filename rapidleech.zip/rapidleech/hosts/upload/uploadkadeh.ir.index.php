<?php
$upload_services[] = 'uploadkadeh.ir';
$max_file_size['uploadkadeh.ir'] = 2048;
$page_upload['uploadkadeh.ir'] = 'uploadkadeh.ir.php';  
?>