<?php
$upload_services[]="hellshare.com_member";
$max_file_size["hellshare.com_member"]=1000;
$page_upload["hellshare.com_member"] = "hellshare.com_member.php";
?>