<?php
$upload_services[]="filedropper.com";
$max_file_size["filedropper.com"]=5000;
$page_upload["filedropper.com"] = "filedropper.com.php";  
?>