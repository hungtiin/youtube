<?php
$upload_services[] = '180upload.com';
$max_file_size['180upload.com'] = 2048; // Filesize limit (MB)
$page_upload['180upload.com'] = '180upload.com.php';
?>