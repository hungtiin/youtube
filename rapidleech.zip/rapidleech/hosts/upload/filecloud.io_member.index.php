<?php
$upload_services[] = 'filecloud.io_member';
$max_file_size['filecloud.io_member'] = 5120;
$page_upload['filecloud.io_member'] = 'filecloud.io_member.php';
?>