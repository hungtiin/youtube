<?php
$upload_services[]="movshare.net_member";
$max_file_size["movshare.net_member"]=false;
$page_upload["movshare.net_member"] = "movshare.net_member.php";  
?>