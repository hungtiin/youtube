<?php 
$upload_services[]="solidfiles.com";
$max_file_size["solidfiles.com"]=500; 
$page_upload["solidfiles.com"] = "solidfiles.com.php";
?>