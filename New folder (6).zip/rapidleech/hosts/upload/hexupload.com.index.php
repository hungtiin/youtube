<?php
$upload_services[] = 'hexupload.com';
$max_file_size['hexupload.com'] = 2048;
$page_upload['hexupload.com'] = 'hexupload.com.php';  
?>