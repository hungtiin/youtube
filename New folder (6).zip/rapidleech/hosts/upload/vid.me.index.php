<?php
$upload_services[] = 'vid.me';
$max_file_size['vid.me'] = 1024; //No idea what the limit is
$page_upload['vid.me'] = 'vid.me.php';
?>