<?php 
$upload_services[] = 'hugefiles.net';
$max_file_size['hugefiles.net'] = 5000;
$page_upload['hugefiles.net'] = 'hugefiles.net.php';  
?>