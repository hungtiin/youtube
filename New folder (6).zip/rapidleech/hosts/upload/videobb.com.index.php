<?php 
$upload_services[]="videobb.com";
$max_file_size["videobb.com"]=2048;
$page_upload["videobb.com"] = "videobb.com.php";  
?>
