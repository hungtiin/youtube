<?php
$upload_services[] = '1fichier.com';
$max_file_size['1fichier.com'] = 2048;
$page_upload['1fichier.com'] = '1fichier.com.php';
?>