<?php
$upload_services[] = "filepost.com_member";
$max_file_size["filepost.com_member"] = 1000;
$page_upload["filepost.com_member"] = "filepost.com_member.php";  
?>