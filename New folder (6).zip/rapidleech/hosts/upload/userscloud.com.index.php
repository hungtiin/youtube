<?php
$upload_services[] = 'userscloud.com';
$max_file_size['userscloud.com'] = 2048;
$page_upload['userscloud.com'] = 'userscloud.com.php';
?>
