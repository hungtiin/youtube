<?php
$upload_services[] = 'shared.com_member';
$max_file_size['shared.com_member'] = 2000;
$page_upload['shared.com_member'] = 'shared.com_member.php';
?>