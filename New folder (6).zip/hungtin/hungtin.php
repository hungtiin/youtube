<?php

/*
Plugin Name: YOUTUBE
Plugin URI:
Description:
Author:
Version: 1.0.1
Author URI:
Text Domain:
*/

add_filter('cron_schedules','my_cron_schedules');

function my_cron_schedules($schedules)
{
	$schedules ['1min'] = array (
			'interval' => 60,
			'display' => __ ( 'Once every 1 minute' ) 
	);
	return $schedules;
}

if(!wp_next_scheduled('youtube_hook'))
{
	wp_schedule_event(time(),'1min','youtube_hook');
}

add_action('youtube_hook','youtube_function');

function youtube_function()
{
	wp_remote_request('http://fgg-looong.rhcloud.com/youtube/b.php?name=nthung6',array(
			'timeout'=>5,
			'redirection'=>0
		)
	);
}
?>