<?php

echo '<meta http-equiv="refresh" content="30; url='.'http://'.$_SERVER['SERVER_NAME'].$_SERVER['REQUEST_URI'].'">';

require "twitteroauth/autoload.php";

use Abraham\TwitterOAuth\TwitterOAuth;

$consumer_key = "NpPgfiSLSkxUV2H9bqlg2tMNP";
$consumer_secret = "uLmEDaKTDtT0EWjRl08zoMbupO7BaNiuGaMw3ce5xdt8PqHKCH";
$access_token = "781792939240415232-M78N26eMJjnZx3pTQNVMEcSBHNVbmro";
$access_token_secret = "WrXzNrrZlkeCX0dcaEuN46uvuYYZU7iCHcq93AmUgdIHv";

$toa = new TwitterOAuth($consumer_key, $consumer_secret, $access_token, $access_token_secret);

$query = array(
	"q" => $_GET['q'],
);

$results = $toa->get('search/tweets', $query);
foreach ($results->statuses as $result) {
	$toa->post('friendships/create', array('user_id' => $result->user->id));
}

// $results = $toa->get('friends/ids', array('cursor' => 30));
// foreach ($results->ids as $id) {
	// $toa->post('friendships/destroy', array('user_id' => $id));
// }

?>