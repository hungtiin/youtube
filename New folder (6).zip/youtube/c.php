<?php

$host = '45.63.127.24:3306';
$username = 'adminEcbIXjt';
$password = 'PRgL9J11jSVU';
$dbname = 'google';

?>