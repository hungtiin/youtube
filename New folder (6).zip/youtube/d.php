<?php
set_time_limit(0);

$COOKIEJAR = 'cookies/'.rand().'.txt';
$USERAGENT = 'Mozilla/5.0 (X11; U; Linux i686; en-US; rv:1.9.0.13) Gecko/2009080315 Ubuntu/9.04 (jaunty) Firefox/3.0.13';

function get($URL,$REFERER,$COOKIEJAR,$USERAGENT)
{
	$ch = curl_init();
	curl_setopt($ch,CURLOPT_REFERER,$REFERER); 
	curl_setopt($ch,CURLOPT_URL,$URL);
	curl_setopt($ch,CURLOPT_USERAGENT,$USERAGENT);
	curl_setopt($ch,CURLOPT_COOKIEJAR,$COOKIEJAR);
	curl_setopt($ch,CURLOPT_COOKIEFILE,$COOKIEJAR);
	curl_setopt($ch,CURLOPT_PROTOCOLS,CURLPROTO_HTTPS);
	curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
	curl_setopt($ch,CURLOPT_FOLLOWLOCATION,1);
	curl_setopt($ch,CURLOPT_TIMEOUT,30);
	$page = curl_exec($ch);
	curl_close($ch);
	return $page;
}

function post($URL,$POSTFIELDS,$REFERER,$COOKIEJAR,$USERAGENT)
{
	$ch = curl_init();
	curl_setopt($ch,CURLOPT_URL,$URL);
	curl_setopt($ch,CURLOPT_USERAGENT,$USERAGENT);
	curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,FALSE); 
	curl_setopt($ch,CURLOPT_COOKIEJAR,$COOKIEJAR);
	curl_setopt($ch,CURLOPT_COOKIEFILE,$COOKIEJAR);
	curl_setopt($ch,CURLOPT_PROTOCOLS,CURLPROTO_HTTPS);
	curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
	curl_setopt($ch,CURLOPT_FOLLOWLOCATION,1);
	curl_setopt($ch,CURLOPT_POSTFIELDS,$POSTFIELDS); 
	curl_setopt($ch,CURLOPT_POST,1); 
	curl_setopt($ch,CURLOPT_TIMEOUT,30);
	$page = curl_exec($ch);
	curl_close($ch);
	return $page;
}

// giao dien
echo '<meta charset="UTF-8">';
echo '<form method="post">';
echo 'Tài khoản:<br>';
echo '<textarea name="accounts" rows="10" cols="50">
abc@abc.com:123456
abc@abc.com:123456
</textarea><br>';
echo '<input type="submit" name="submit" value="Submit">';
echo '</form>';
echo '<a href="http://google1-trangta.rhcloud.com/e.php">Tạo Playlist</a>';

// code
if(isset($_POST['accounts']))
{
	$accounts = explode(PHP_EOL,$_POST['accounts']);

	for ($b = 0; $b < count($accounts); $b++)
	{
		$account = explode(':',$accounts[$b]);
		$Email = $account[0];
		$Passwd = $account[1];
		
		// Lay GALX,gxf
		$page = get('https://www.google.com/accounts/ServiceLogin?uilel=3&service=youtube&passive=true&continue=http://www.youtube.com/signin?action_handle_signin=true&nomobiletemp=1&hl=en_US&next=%2Findex&hl=en_US&ltmpl=sso','http://www.youtube.com/',$COOKIEJAR,$USERAGENT);

		preg_match('/<input type="hidden" name="gxf" value="([^"]+)">/',$page,$matches);
		$gxf = $matches[1];

		preg_match('/<input type="hidden" name="GALX" value="([^"]+)">/',$page,$matches);
		$GALX = $matches[1];

		// Dang nhap youtube
		$post = 'GALX='.$GALX.'&Email='.$Email.'&Passwd='.$Passwd.'&gxf='.$gxf;
		$page = post('https://www.google.com/accounts/ServiceLoginAuth?service=youtube',$post,'http://www.youtube.com/',$COOKIEJAR,$USERAGENT);

		// Lay thong tin youtube
		$page = get('https://www.youtube.com/view_all_playlists','http://www.youtube.com/',$COOKIEJAR,$USERAGENT);
		
		preg_match('/<span id="creator-subheader-item-count" class="yt-badge-creator">(\d+)<\/span>/',$page,$matches);
		$playlist_count = $matches[1];
		
		$page = get('https://www.youtube.com/dashboard?o=U','http://www.youtube.com/',$COOKIEJAR,$USERAGENT);
		
		preg_match('/<a class="dashboard-channel-link" href="([^"]+)">/',$page,$matches);
		$channel_link = $matches[1];
		
		echo $Email . ':' . $Passwd . ' - ' . '<a target="_blank" href="https://www.youtube.com' . $channel_link . '">' . $channel_link . '</a>' . ' - ' . $playlist_count . '<br>';
	}
}
?>