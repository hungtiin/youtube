<?php
include 'c.php';
set_time_limit(0);

// giao dien
echo '<meta charset="UTF-8">';
echo '<form method="post">';
echo 'Tài khoản:<br>';
echo '<textarea name="accounts" rows="10" cols="50"></textarea><br>';
echo 'Video ID:<br>';
echo '<textarea name="video_ids" rows="10" cols="50">njljnYCGVXo,eaNFDHHljVg,Pw5YRTJC4dc,xERrZbJ_aBU,wPym7mVPd5M,eOIzD7H9bmQ</textarea><br>';
echo 'Từ khóa:<br>';
echo '<textarea name="keywords" rows="10" cols="50"></textarea><br>';
echo '<input type="submit" name="submit" value="Submit"><br>';
echo '</form>';

// code
$count = 0;
if(isset($_POST['accounts'])&&isset($_POST['keywords'])&&isset($_POST['video_ids'])&&isset($_GET['name']))
{
	$name = $_GET['name'];
	$accounts = explode(PHP_EOL,$_POST['accounts']);
	$keywords = explode(PHP_EOL,$_POST['keywords']);
	$video_ids = $_POST['video_ids'];
		
	$con = mysqli_connect($host,$username,$password,$dbname);
	// $con = mysqli_connect('localhost','root','','test');

	// Kiem tra ket noi
	if (mysqli_connect_errno())
	{
	  echo "Failed to connect to MySQL: " . mysqli_connect_error();
	}

	// Perform queries 
	mysqli_query($con,'SELECT * FROM youtube');

	for ($b = 0; $b < count($accounts); $b++)
	{
		for($a = $count;$a<800+$count;$a++)
		{
			$account = explode(':', $accounts[$b]);
			$Email = $account[0];
			$Passwd = $account[1];
			$keyword = strtolower($keywords[$a]);
			
			mysqli_query($con,'INSERT INTO youtube (keyword,video_ids,email,passwd,name) VALUES ("'.$keyword.'","'.$video_ids.'","'.$Email.'","'.$Passwd.'","'.$name.'")');	
		}
		$count = $a;
	}
	
	mysqli_close($con);
}
?>